﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SESSION_8
{
    class BankTransaction
    {
        static void Main()
        {

            Console.WriteLine("Select Account type : (Saving|Current)");
            string AccType = Console.ReadLine();

            
            if (AccType.ToLowerInvariant() == "saving")
            {
                SavingAccount AccSaving = new SavingAccount();
                AccSaving.ShowBalance();

                Console.WriteLine("Please select transaction Process : (Deposite|Withdraw)");
                string acc_process = Console.ReadLine();

                

                if (acc_process.ToLowerInvariant() == "deposite")
                {
                    Console.WriteLine("Please enter amount for deposite");
                    double amount_deposite = Convert.ToDouble(Console.ReadLine());

                    AccSaving.Deposit(amount_deposite);

                }
                else if (acc_process.ToLowerInvariant() == "withdraw")
                {
                    Console.WriteLine("Please enter amount for deposite");
                    double amount_withdraw = Convert.ToDouble(Console.ReadLine());

                    AccSaving.Withdraw(amount_withdraw);
                }
                else
                {
                    Console.WriteLine("Invalid Transaction choice.");
                }

            }
            else if (AccType.ToLowerInvariant() == "current")
            {
                CurrAccount acc_current = new CurrAccount();

                acc_current.CurrentBalance();

                Console.WriteLine("Please select transaction Process : (Deposite|Withdraw)");
                string acc_process = Console.ReadLine();

               

                if (acc_process.ToLowerInvariant() == "deposite")
                {
                    Console.WriteLine("Please enter amount for deposite");
                    double amount_deposite = Convert.ToDouble(Console.ReadLine());

                    acc_current.Deposit(amount_deposite);

                }
                else if (acc_process.ToLowerInvariant() == "withdraw")
                {
                    Console.WriteLine("Please enter amount for deposite");
                    double amount_withdraw = Convert.ToDouble(Console.ReadLine());

                    acc_current.Withdraw(amount_withdraw);
                }
                else
                {
                    Console.WriteLine("Invalid Transaction choice.");
                }

            }
            else
            {
                Console.WriteLine("Invalid Account choice.");
            }

            Console.ReadLine();
        }
    }
}
