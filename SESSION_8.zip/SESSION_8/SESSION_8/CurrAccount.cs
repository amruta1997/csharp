﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SESSION_8
{
    class CurrAccount:BankAccount
    {
        double AccBalance = 50000;

       
        /// Performing Deposite transaction
       
        public void Deposit(double amount)
        {
            Console.WriteLine($"Transaction succesful. Rs. {amount} is succesfully Deposited.");
            AccBalance = AccBalance + amount;
            CurrentBalance();
        }

        
        /// Performing Withdraw Transaction
        
        public void Withdraw(double amount)
        {
            if (amount < AccBalance)
            {
                Console.WriteLine($"Transaction succesful. Rs. {amount} is succesfully Withdrawed.");
                AccBalance = AccBalance - amount;
                CurrentBalance();
            }
            else
            {
                Console.WriteLine("Insufficient Balance.");
                CurrentBalance();
            }

        }

        
        /// Displaing account balance after a successfull transaction
        
        public void CurrentBalance()
        {
            Console.WriteLine($"Current Balance: RS {AccBalance}");
        }
    }
}
