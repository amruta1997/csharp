﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SESSION_8
{
    abstract class Computer
    {
        public abstract string Booting();

        public abstract string ShuttingDown();
    }
    class SuperComputer : Computer
    {
       
        /// Implimenting methods from abstract class
        
        public override string Booting()
        {
            return "SuperComputer Booting Up";
        }

        public override string ShuttingDown()
        {
            return "SuperComputer Shutting Down";
        }
    }

    class MainfraimComputer : Computer
    {
        
        /// Implementing methods from inherited abstract class
       
        public override string Booting()
        {
            return "MainfraimComputer Booting Up";
        }

        public override string ShuttingDown()
        {
            return "MainfraimComputer Shutting Down";
        }
    }

    class MicroComputer : Computer
    {
        
        /// Implimenting methods from abstract class 
        
        public override string Booting()
        {
            return "MicroComputer Booting Up";
        }

        public override string ShuttingDown()
        {
            return "MicroComputer Shutting Down";
        }
    }

    class ComputerMain
    {
        static void Main()
        {

            SuperComputer s_comp = new SuperComputer();
            Console.WriteLine(s_comp.Booting());
            Console.WriteLine(s_comp.ShuttingDown());

            MainfraimComputer main_comp = new MainfraimComputer();
            Console.WriteLine(main_comp.Booting());
            Console.WriteLine(main_comp.ShuttingDown());

            MicroComputer micro_comp = new MicroComputer();
            Console.WriteLine(micro_comp.Booting());
            Console.WriteLine(micro_comp.ShuttingDown());

            Console.ReadLine();

        }
    }
    }
