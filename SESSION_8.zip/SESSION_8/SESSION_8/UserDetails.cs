﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SESSION_8
{
    class UserDetails
    {
        private long id;
        private string name;
        private string email;
        private string dob;

        public UserDetails(long id, string name, string email, string dob)
        {
            this.id = id;
            this.name = name;
            this.email = email;
            this.dob = dob;
        }

        public long UserId
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string UserName
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string UserEmail
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public string UserDob
        {
            get
            {
                return dob;
            }

            set
            {
                dob = value;
            }
        }

        public override string ToString()
        {
            return $"Registration Details\n User ID: {UserId} | User Name: {UserName} | User Mail: {UserEmail} | Date of Birth: {UserDob}";
        }

        public static bool Validate_mail(List<UserDetails> userDetailsList, string useremail)
        {
            foreach (var temp in userDetailsList)
            {
                if (temp.UserEmail == useremail)
                {
                    return false;
                }
            }

            return true;

        }

    }

    class UserRegistration
    {


        static void Main()
        {

            List<UserDetails> uDetails_list = new List<UserDetails>();
            string choice;

            do
            {
                Console.WriteLine("Enter user ID:");
                int UserId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter User Name:");
                string UserName = Console.ReadLine();

                Console.WriteLine("Enter Email address:");
                string UserEmail = Console.ReadLine();

                bool validation = UserDetails.Validate_mail(uDetails_list, UserEmail);
                while (!validation)
                {
                    Console.WriteLine("This email is already exist. Please Enter another mail ID.");
                    Console.WriteLine("Enter Another Email address:");
                    UserEmail = Console.ReadLine();
                    validation = UserDetails.Validate_mail(uDetails_list, UserEmail);
                }

                Console.WriteLine("Enter Date of birth");
                string UserDob = Console.ReadLine();

                UserDetails uDetails = new UserDetails(UserId, UserName, UserEmail, UserDob);

                uDetails_list.Add(uDetails);

                Console.WriteLine($"User Details:\n {uDetails}");

                Console.WriteLine($"Another Registration(y/n) ??");
                choice = Console.ReadLine();

            } while (!(choice == "n"));

            Console.ReadLine();
        }
    }
}
}
