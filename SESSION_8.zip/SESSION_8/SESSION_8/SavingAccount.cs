﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SESSION_8
{
    class SavingAccount:BankAccount
    {
        double AccBalance = 60000; 

       
        ///  Deposite transaction
        
        public void Deposit(double amount)
        {
            Console.WriteLine($"Transaction is succesful. Rs. {amount} is succesfully Deposited.");
            AccBalance = AccBalance + amount;
            ShowBalance();
        }

        /// <summary>
        /// Performing withdraw Transaction
        /// </summary>
        public void Withdraw(double amount)
        {
            if (amount < AccBalance)
            {
                Console.WriteLine($"Transaction is succesful. Rs. {amount} is succesfully Withdrawed.");
                AccBalance = AccBalance - amount;
                ShowBalance();
            }
            else
            {
                Console.WriteLine("Insufficient Balance.");
                ShowBalance();
            }

        }

        /// <summary>
        /// Displaying account balance after successfull transaction
        /// </summary>
        public void ShowBalance()
        {
            Console.WriteLine($"Account Balance: RS {AccBalance }");
        }
    }
}
