﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SESSION_8
{
    class Hotel
    {
        private int RoomNumber;
        private int RoomFloor;
        private string RoomType;
        private int RoomCapacity;
        private DateTime RoomBookedTime;
        private double RoomPrice;

        
        public Hotel(int RoomNumber, int RoomFloor, string RoomType, int RoomCapacity, DateTime RoomBookedTime, double RoomPrice)
        {
            this.RoomNumber = RoomNumber;
            this.RoomFloor = RoomFloor;
            this.RoomType = RoomType;
            this.RoomCapacity = RoomCapacity;
            this.RoomBookedTime = RoomBookedTime;
            this.RoomPrice = RoomPrice;
        }

        public int Room_number
        {
            get
            {
                return RoomNumber;
            }

            set
            {
                if (value <= 0)
                {
                    Console.WriteLine("Invalid Room no");
                }
                else
                {
                    RoomNumber = value;
                }

            }
        }

        public int Room_floor
        {
            get
            {
                return RoomFloor;
            }

            set
            {
                RoomFloor = value;
            }
        }

        public string Room_type
        {
            get
            {
                return RoomType;
            }

            set
            {
                if (value == "ac")
                {
                    RoomType = "AC Room";
                }
                else
                {
                    RoomType = "Non-AC room";
                }
            }
        }

        public int Room_capacity
        {
            get
            {
                return RoomCapacity;
            }

            set
            {
                RoomCapacity = value;
            }
        }
        public DateTime Room_bookingTime
        {
            get
            {
                return RoomBookedTime;
            }

            set
            {
                RoomBookedTime = value;
            }
        }

        public double Room_price
        {
            get
            {
                return RoomPrice;
            }

            set
            {
                RoomPrice = value;
            }
        }
        /// <summary>
        /// Overriding ToString method
        /// </summary>
        public override string ToString()
        {
            return $"Room Booking Details \nRoom No:{Room_number} | Floor No:{Room_floor} | Room Type:{Room_type} | Room Capacity:{Room_capacity} | CheckIn Date: {r_bookedTime} | Room Charges(per Day):{Room_price}";
        }
    }
    class Hotel_main
    {
        static void Main()
        {
            
            Console.WriteLine("Enter Hotel Room No:");
            int Room_number = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Floor no:");
            int Room_floor = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Room type");
            string Room_type = Console.ReadLine();

            Console.WriteLine("Enter no of Peope:");
            int Room_capacity = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Checkin Date:");
            DateTime Room_bookingTime = Convert.ToDateTime(Console.ReadLine());

            Console.WriteLine("Enter Price for room");
            Double Room_price = Convert.ToDouble(Console.ReadLine());

            Hotel hotel1 = new Hotel(Room_number, Room_floor, Room_type, Room_capacity, Room_bookingTime, Room_price);

            Console.WriteLine(hotel1);

            Console.ReadLine();
        }
    }
}
