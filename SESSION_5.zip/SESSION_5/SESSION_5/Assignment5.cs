﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//ASCII to Integer Conversion and vice versa

namespace SESSION_5
{
    class Assignment5
    {
        static void Main()
        {
            char[,] num = new char[4, 3] { { 'A', 'B', 'C' }, { 'D', 'E', 'F' }, { 'G', 'H', 'I' }, { 'J', 'K', 'L' } };
            Console.WriteLine("Character Array :");

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}", num[i, j]);

                }
                Console.WriteLine();

            }

            Console.WriteLine("Integer Array : ");
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}", Convert.ToInt32(num[i, j]));

                }
                Console.WriteLine();

            }
            Console.ReadLine();
        }


    }
}
