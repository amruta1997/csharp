﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

///Sum of Diagonal elements of multi dimensional array

namespace SESSION_5
{
    class Assignment2
    {
        static void Main()
        {
            int[,] num = new int[3, 3];
            Console.WriteLine("Enter elements : ");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    num[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine(" Array Elements are : ");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0}", num[i, j]);
                }
                Console.WriteLine();
            }

            int sum = 0;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (i == j)
                    {
                        sum = sum + num[i, j];
                    }
                }

            }
            Console.WriteLine("Sum of Diagonal Elements is = {0} ", sum);
            Console.ReadLine();
        }
    }
}
