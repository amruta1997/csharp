﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Sum of Elements of single dimensional array
namespace SESSION_5
{
    class Assignment1
    {
        static void Main()
        {
            int[] num = new int[6] { 1, 2, 3, 4, 5, 6 };
            Console.WriteLine("Array Elements are : ");
            foreach (int temp in num)
            {
                Console.WriteLine(temp);
            }

            int sum = 0;
            for (int i = 0; i < num.Length; i++)
            {
                sum = sum + num[i];
            }
            Console.WriteLine("Sum of elements of nums array = {0} ", sum);
            Console.ReadLine();
        }
    }
}
