﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Calculate factorial of number using function
namespace SESSION_6
{
    class Assignment1
    {
        public static void fact(int n)
        {
            int fact = 1;

            while (n > 0)
            {
                fact = fact * n--;

            }
            Console.WriteLine("Factorial = {0} ", fact);

        }

        static void Main()
        {
            Console.WriteLine("Enter Number : ");
            int n = Convert.ToInt32(Console.ReadLine());
            fact(n);

            Console.ReadLine();
        }
    }
}
