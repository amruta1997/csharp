﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Print all cities STD code in Enum

namespace SESSION_7
{
    class Assignment2
    {
        static void Main()
        {
            
            Console.WriteLine("All available cities:");
            foreach (string state in Enum.GetNames(typeof(City_code)))
            {
                Console.WriteLine(state);
            }
            
            Console.WriteLine("Std code for all cities:");
            foreach (int val in Enum.GetValues(typeof(City_code)))
            {
                Console.WriteLine(val);
            }

            Console.ReadLine();
        }
    }
}
