﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SESSION_7
{
    class Assignment1
    {

    }
    struct Student
    {
        int RollNo;
        string Name;
        char Gender;
        long MobNo;

        public Student(int RollNo, string Name, char Gender, long MobNo)
        {
            this.RollNo = RollNo;
            this.Name = Name;
            this.Gender = Gender;
            this.MobNo = MobNo;
        }


        public string display()
        {
            return string.Format("Roll Number = {0}\n Name = {1}\n Gender(M/F) = {2}\n Mobile No = {3}\n", RollNo, Name, Gender, MobNo);
        }
    }
}
