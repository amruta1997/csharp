﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SESSION_7
{
   
        public enum City_code
    {
            Pune = 201, Amravati = 100, Jalgaon = 987, hyderabad = 398, chennai = 400
    };
    }
