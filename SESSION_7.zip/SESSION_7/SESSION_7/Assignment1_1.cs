﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 //display student values by creating constructor and print using function
namespace SESSION_7
{
    class Assignment1_1
    {
        static void Main()
        {
            Student st = new Student(1, "Amruta", 'F', 987654321);
            Console.WriteLine(st.display());
            Console.ReadLine();
        }
    }
}
