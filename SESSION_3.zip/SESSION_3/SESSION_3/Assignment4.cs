﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//	Develop a program to decide whether person is major or minor person using Ternary operator.
namespace SESSION_3
{
    class Assignment4
    {
        static void Main()
        {
            Console.WriteLine("Enter your Age:");
            int i = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(i > 18 ? "your Age is Major" : "your Age is Minor");
            Console.ReadLine();
        }
    }
}
