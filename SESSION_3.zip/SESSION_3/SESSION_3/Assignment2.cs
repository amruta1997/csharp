﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SESSION_3
     //  Develop a program to decide grade according to percentage using If-else if-else.
{
    class Assignment2
    {
        static void Main()
        {
            Console.WriteLine("Enter your percentage : ");
            int per = Convert.ToInt32(Console.ReadLine());
            if (per >= 70)
            {
                Console.WriteLine("Your grade is A.");
            }
            else if (per < 70 && per >= 40)
            {
                Console.WriteLine("Your grade is B.");
            }
            else
            {
                Console.WriteLine("You are Fail.");
            }
            Console.ReadLine();
        }
    }
}
