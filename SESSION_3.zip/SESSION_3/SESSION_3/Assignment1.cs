﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//	Develop a program to decide whether person is major or minor using if-else statement.

namespace SESSION_3
{
    class Assignment1
    {
        static void Main()
        {
            
            Console.WriteLine("Enter your Age:");
            int i = Convert.ToInt32(Console.ReadLine());
            if (i <= 18)
            {
                Console.WriteLine("Your Age is Minor");
            }
            else
            {
                Console.WriteLine("Your Age is Major");
            }
            Console.ReadLine();
        }
    }
}
