﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Write a program to display odd numbers between 1 to 50 using foreach from given array.
namespace SESSION_4
{
    class Assignment3
    {
        static void Main()
        {
            int[] arr = new int[50];
            Console.WriteLine("Enter numbers: ");
            for (int i = 0; i <= 5; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("odd no:");
            foreach (int temp in arr)
            {
                if (temp % 2 != 0 && temp > 1 && temp <= 50)
                {
                    Console.WriteLine(temp);
                }
            }
            Console.ReadLine();
        }
    }
}
