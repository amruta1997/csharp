﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//	Write a program to display numbers in reverse order from 50 to 1 using for Loop construct.
namespace SESSION_4
{
    class Assignment1
    {

        static void Main()
        {
            Console.WriteLine("Reverse order numbers are:");
            for (int i = 50; i >= 1; i--)
            {
                Console.WriteLine(i);

            }
            Console.ReadLine();
        }

    }
}
