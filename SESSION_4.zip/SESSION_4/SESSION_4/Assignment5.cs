﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Write a program to print table of given number using for loop.


namespace SESSION_4
{
    class Assignment5
    {
        static void Main()
        {

            Console.WriteLine("Enter Numbers : ");
            int num = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i <= 10; i++)
            {
                int table = num * i;
                Console.WriteLine("{0}*{1}={2}", num, i, table);
            }

            Console.ReadLine();
        }
    }
}
