﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//	Write a program to display odd numbers between 1 to 50 using do while Loop.
namespace SESSION_4
{
    class Assignment2
    {
        static void Main()
        {
            int i = 1;

            Console.WriteLine("odd numbers between 1 to 50 are : ");

            do
            {
                if (i % 2 != 0)
                {
                    Console.WriteLine(i);
                }
                i++;
            } while (i <= 50);
            Console.ReadLine();
        }
    }
}
