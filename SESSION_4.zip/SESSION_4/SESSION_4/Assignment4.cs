﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//	Write a program identify and display even number from given array using foreach Loop.
namespace SESSION_4
{
    class Assignment4
    {
        static void Main()
        {
            int[] arr = new int[50];
            Console.WriteLine("Enter numbers: ");
            for (int i = 0; i <= 5; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("even no:");
            foreach (int temp in arr)
            {
                if (temp % 2 == 0 && temp > 1 && temp <= 50)
                {
                    Console.WriteLine(temp);
                }
            }
            Console.ReadLine();
        }
    }
}
